# 05 — Data, State and API Contract

## Server source of truth

Server must own:
- price, promotion, tax, shipping and totals
- stock, reservation and purchase limits
- drop start/end time
- payment status
- order status
- seller verification
- permissions and role access
- COA/serial validity

## Required domain entities

`User`, `Session`, `Address`, `Seller`, `Shop`, `Product`, `Variant`, `Inventory`, `Collection`, `Drop`, `Cart`, `CartItem`, `Order`, `OrderItem`, `Payment`, `Shipment`, `Return`, `Refund`, `Voucher`, `COA`, `Notification`, `Message`, `AuditLog`.

## API behavior

- All mutation endpoints require idempotency key where duplicate action is harmful
- Checkout creates a server quote before payment
- Stock is revalidated before reservation and before payment capture
- Payment webhook is authoritative
- Client never stores card data
- Optimistic updates are allowed only when rollback is deterministic
- Every admin mutation creates an audit record
- Every list endpoint supports pagination and stable sorting
- Errors use a typed envelope:

```ts
type ApiError = {
  code: string;
  message: string;
  fieldErrors?: Record<string, string>;
  retryable: boolean;
  requestId: string;
};
```

## Frontend state boundaries

- URL: filters, search, pagination, selected tab when shareable
- Server state: products, inventory, orders, payments
- Local UI state: open sheet, active image, animation state
- Persisted client state: theme, consent, non-sensitive preferences
- Never persist auth token, card data or authoritative price in localStorage
