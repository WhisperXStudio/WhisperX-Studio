# 04 — Motion System

## Motion families

| Family | Meaning | Typical use |
|---|---|---|
| Orbit | guided circular movement | mascot, progress, collection |
| Snap | fast decisive response | tabs, filter, navigation |
| Squish | tactile press feedback | buttons, chips, save |
| Float | low-energy atmosphere | hero objects, cards |
| Warp | route/section transition | immersive campaign only |
| Mischief | playful interruption | Orbit hints, empty states |
| Reward | success and collection gain | purchase, save, unlock |
| Lock | verification and trust | COA, payment, security |

## Timing

- Instant 120ms
- Quick 180ms
- Responsive 280ms
- Expressive 480ms
- Story 800ms
- Cinematic 1200ms

## Rules

- Motion must explain hierarchy, causality, state or reward
- Do not animate every element
- Maximum active ambient loops: desktop 3, mobile 1
- Pause loops offscreen
- Route transition must not delay navigation
- Static first frame must be production quality
- `prefers-reduced-motion` removes parallax, orbit travel, magnetic movement and continuous loops
- Loading animations must reflect real work and never fake progress
