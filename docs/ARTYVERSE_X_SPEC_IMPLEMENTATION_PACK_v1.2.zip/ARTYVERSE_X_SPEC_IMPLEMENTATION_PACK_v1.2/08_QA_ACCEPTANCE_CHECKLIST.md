# 08 — QA Acceptance Checklist

## Build
- [ ] `npm ci`
- [ ] `npm run lint`
- [ ] `npm run typecheck`
- [ ] `npm test`
- [ ] `npm run build`
- [ ] No missing exports or unresolved aliases

## Brand
- [ ] No `ARTVERSE`
- [ ] ARTYVERSE used for product/legal/transaction
- [ ] ARTYVERSE X used only for campaign/immersive context
- [ ] Orbit has a functional role

## UI
- [ ] Every page has memorable moment
- [ ] Every transactional page has conversion anchor
- [ ] Loading/empty/error/success/offline states
- [ ] No lorem ipsum or gray-box final placeholders
- [ ] Light and dark themes reviewed

## Responsive
- [ ] 320, 375, 480, 768, 1024, 1280, 1600px
- [ ] No overflow
- [ ] Navigation and sheets usable
- [ ] Tables and charts readable
- [ ] Sticky CTA does not cover content

## Accessibility
- [ ] Keyboard path
- [ ] Focus visibility
- [ ] Screen-reader labels
- [ ] Contrast
- [ ] Reduced motion
- [ ] Dialog focus management

## Commerce integrity
- [ ] Server totals
- [ ] Stock revalidation
- [ ] Idempotent checkout/payment
- [ ] Duplicate-click protection
- [ ] Webhook-driven payment status
- [ ] Refund and return states

## Performance
- [ ] LCP ≤ 2.5s
- [ ] INP ≤ 200ms
- [ ] CLS ≤ 0.10
- [ ] Initial JS ≤ 170kB gzip target
- [ ] Hero image ≤ 350kB mobile
- [ ] Offscreen animation paused

## Release
- [ ] No blockers
- [ ] Acceptance score ≥ 90/100
- [ ] Product, Design and Engineering sign-off
