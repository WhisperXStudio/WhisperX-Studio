# 01 — Build Scope and Route Matrix

## Public Storefront

| Screen | Route | Required states |
|---|---|---|
| Home | `/` | default, loading, campaign, reduced-motion |
| Marketplace | `/marketplace` | default, filtered, searched, loading, empty, error |
| Category | `/marketplace/category/[slug]` | default, empty, pagination |
| Search | `/search?q=` | results, no-results, suggestions |
| Product detail | `/marketplace/[slug]` | available, low-stock, sold-out, preorder |
| Gallery zoom | product modal/sheet | open, swipe, keyboard |
| Seller profile | `/shop/[slug]` | verified, unavailable |
| Collection | `/collection/[slug]` | active, completed |
| Limited drop | `/drop/[slug]` | upcoming, live, sold-out, ended |
| Wishlist | `/wishlist` | populated, empty |
| Cart | `/cart` | populated, empty, stock-changed |
| Checkout | `/checkout` | address, delivery, payment, review |
| Payment result | `/checkout/result` | success, failed, pending |
| Guest tracking | `/track` | form, found, not-found |
| COA verify | `/verify/[serial]` | verified, invalid, revoked |
| Community | `/community` | feed, empty, moderation state |
| Help | `/help` | search, article, contact |

## Authentication and Account

| Screen group | Route pattern |
|---|---|
| Login/Register/OTP/Password | `/auth/[mode]` |
| Account overview | `/account` |
| Profile | `/account/profile` |
| Address book | `/account/addresses` |
| Payment methods | `/account/payments` |
| Orders | `/account/orders` |
| Order detail | `/account/orders/[id]` |
| Tracking | `/account/tracking/[id]` |
| Return request/status | `/account/returns/[id]` |
| Reviews | `/account/reviews` |
| Messages | `/account/messages` |
| Vouchers/Credits | `/account/rewards` |
| Following/Saved shops | `/account/following` |
| Notifications | `/account/notifications` |
| Security/Sessions | `/account/security` |

## Seller Center

Use `/seller` as the shell and nested routes:
`dashboard`, `onboarding`, `verification`, `shop`, `products`, `products/new`, `products/[id]`, `inventory`, `pricing`, `shipping`, `bulk-import`, `orders`, `orders/[id]`, `fulfillment`, `labels`, `returns`, `disputes/[id]`, `promotions`, `coupons`, `drops`, `analytics`, `finance`, `coa`, `staff`, `settings`.

## Admin Operations

Use `/admin` as the shell and nested routes:
`dashboard`, `users`, `users/[id]`, `sellers`, `sellers/[id]`, `moderation`, `moderation/[id]`, `categories`, `collections`, `orders`, `orders/[id]`, `payments`, `refunds`, `disputes`, `fees`, `campaigns`, `cms`, `community`, `shipping`, `tax`, `reports`, `audit`, `integrations`, `roles`, `settings`, `health`.

## Required cross-route behaviors

- Route-level loading and error boundaries
- Breadcrumb and back behavior
- Auth/role guard
- Deep-link restoration
- SEO metadata for public routes
- Unsaved-change guard for seller/admin forms
- Empty, offline and permission-denied states
