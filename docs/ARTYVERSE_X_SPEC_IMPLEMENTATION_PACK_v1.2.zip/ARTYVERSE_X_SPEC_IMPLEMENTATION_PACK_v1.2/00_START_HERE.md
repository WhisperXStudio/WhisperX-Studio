# ARTYVERSE X — Spec Implementation Pack v1.2

ชุดเอกสารนี้เป็น Source of Truth สำหรับสร้าง ARTYVERSE X ให้ตรงสเปกทั้ง Figma, Next.js/React/TypeScript, HTML/CSS/JavaScript และ Responsive Web

## ลำดับการใช้งาน

1. อ่าน `ARTYVERSE_X_FULL_PRODUCTION_POLISH_SPEC_v1.1.docx`
2. ใช้ `01_BUILD_SCOPE_AND_ROUTE_MATRIX.md` ล็อกหน้าจอและ route
3. ใช้ `02_COMPONENT_AND_STATE_CONTRACT.md` สร้าง component
4. import token จาก `03_DESIGN_TOKENS.json`
5. ใช้ `04_MOTION_SYSTEM.md` กำหนด animation
6. ใช้ `05_DATA_STATE_API_CONTRACT.md` เชื่อม state และ backend
7. ใช้ `06_RESPONSIVE_ACCESSIBILITY_CONTRACT.md` ตรวจทุก breakpoint
8. ทำตาม `07_IMPLEMENTATION_SEQUENCE.md`
9. ตรวจด้วย `08_QA_ACCEPTANCE_CHECKLIST.md`
10. ใช้ `09_CODEX_MASTER_BUILD_PROMPT.md` เมื่อต้องสั่ง Codex/AI Agent

## กฎสูงสุด

- Brand หลักต้องเป็น `ARTYVERSE`
- `ARTYVERSE X` ใช้กับ campaign / immersive / experimental surfaces
- ห้ามมีคำว่า `ARTVERSE`
- UI ต้องไม่ดูเป็น marketplace template สำเร็จรูป
- ทุกหน้าต้องมี memorable moment + conversion anchor
- Server เป็น source of truth สำหรับราคา สต็อก คำสั่งซื้อ การชำระเงิน และสิทธิ์
- งานยังไม่เสร็จจนกว่า QA checklist จะผ่านครบและ build สำเร็จ
