# 06 — Responsive and Accessibility Contract

## Breakpoints

- 320–479 Compact
- 480–767 Mobile
- 768–1023 Tablet
- 1024–1279 Desktop
- 1280–1599 Wide
- 1600+ Cinema atmosphere with capped content

## Responsive gates

- No horizontal overflow at 320px
- Mobile is recomposed, not scaled
- Primary CTA remains reachable in thumb zone
- Tables become cards or controlled horizontal scroll
- Product media keeps explicit aspect ratio
- Sticky elements never cover focused content
- Hover-only content must have focus/tap equivalent

## WCAG 2.2 AA gates

- Semantic landmarks
- One visible H1 per page
- Logical heading order
- Keyboard complete
- Visible focus
- 44×44px touch targets
- Form labels and error association
- Status messages via live regions
- Contrast verified in both themes
- Images have meaningful alt or empty alt when decorative
- Dialog focus trap and restoration
- Reduced-motion support
- Error does not rely on color alone
