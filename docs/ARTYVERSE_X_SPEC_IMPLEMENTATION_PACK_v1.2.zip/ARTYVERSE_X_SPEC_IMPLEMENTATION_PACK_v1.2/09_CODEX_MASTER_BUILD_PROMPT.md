# 09 — Codex Master Build Prompt

Build ARTYVERSE X from the documents in this pack. Treat the documents as binding contracts, not inspiration.

## Execution rules

1. Audit the repository before editing.
2. Run the current build and record all failures.
3. Do not replace working architecture without evidence.
4. Use Next.js App Router, React and TypeScript.
5. Keep domain state separate from animation state.
6. Reuse the token and component contracts in this pack.
7. Implement all routes and required states in the route matrix.
8. Do not create generic marketplace layouts.
9. Use ARTYVERSE as the primary brand and ARTYVERSE X for campaign surfaces.
10. Remove every legacy `ARTVERSE` occurrence.
11. Make mobile a recomposed interface, not a scaled desktop.
12. Use purposeful motion and complete reduced-motion fallbacks.
13. Server must remain source of truth for price, stock, payment and permissions.
14. Add tests for routes, state unions, accessibility and build compatibility.
15. Do not claim completion until lint, typecheck, tests and production build pass.

## Required delivery

- production source code
- complete route coverage
- shared design tokens
- typed component APIs
- loading/empty/error/success/offline states
- responsive behavior from 320px upward
- accessibility compliance
- backend integration interfaces
- tests and QA report
- release notes
- unresolved backend dependencies clearly listed

## Definition of done

The result must satisfy `08_QA_ACCEPTANCE_CHECKLIST.md` with no release blocker. A visually polished mock that does not build, lacks states or uses fake commerce logic is not complete.
