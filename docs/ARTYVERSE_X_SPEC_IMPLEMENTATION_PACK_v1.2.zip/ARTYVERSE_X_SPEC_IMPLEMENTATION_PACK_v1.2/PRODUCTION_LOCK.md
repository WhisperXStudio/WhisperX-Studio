# ARTYVERSE X — Production Lock

## Brand

- Primary name: `ARTYVERSE`
- Campaign / experimental lockup: `ARTYVERSE X`
- Tone: modern, playful, slightly mischievous, premium, never childish
- Palette: Deep Black `#07080B`, Off White `#F7F7F7`, Neon Lime `#C6FF00`, Neon Pink `#FF2DB7`, Graphite `#24262D`, Concrete `#D8D8D8`

## Layout

- Desktop max content width: `1440px`
- Standard section inset: `clamp(20px, 5vw, 72px)`
- Main radius: `28px`; card radius: `20px`; controls: pill
- Desktop product grid: 4 columns; tablet: 2; mobile: 1
- Content must remain readable at 320px and must not rely on hover

## Motion language

| Token | Duration | Usage |
|---|---:|---|
| `instant` | 120ms | visual feedback |
| `quick` | 180ms | hover/tap/toggle |
| `responsive` | 280ms | card/drawer/tab |
| `expressive` | 480ms | overlays/shared transitions |
| `story` | 800ms | section reveals |

Easings:

- `snap`: `cubic-bezier(.2,.9,.25,1)`
- `orbit`: `cubic-bezier(.16,1,.3,1)`
- `exit`: `cubic-bezier(.7,0,.84,0)`

Rules:

- Animate `transform` and `opacity` first.
- Use blur only on low-frequency decorative layers.
- Stop background loops outside viewport.
- Reduced motion removes orbit/parallax and preserves state clarity.
- Mobile uses tap/drag/scroll feedback, never hover-only actions.

## Custom node components

- `OrbitPortal` — mascot + contextual state surface
- `ProductCapsule` — product visual, identity, price, inventory and actions
- `MagneticCTA` — desktop magnetic response, mobile squish response
- `DropReactor` — countdown, stock, campaign and CTA
- `OrbitRail` — responsive product rail / carousel
- `WarpTabs` — shared active indicator and content transition
- `CollectorPulse` — level, collection progress and rewards
- `SellerSignal` — severity-aware operational alert

## HTML mapping

- Semantic tags: `header`, `nav`, `main`, `section`, `article`, `button`
- State via `data-state`, `aria-current`, `aria-expanded`, `aria-live`
- Motion via CSS custom properties and Web Animations API
- No essential information inside canvas-only or decorative layers

## React mapping

- Components use typed props and local state
- Motion import: `motion/react`
- Shared motion configuration is centralized
- List content requires stable keys
- Lazy-load route-level sections and media
- Use `useReducedMotion` for all expressive motion branches

## Quality gates

- Keyboard focus visible on every actionable element
- Touch targets at least 44x44px
- Contrast verified for lime/pink on both dark and light surfaces
- LCP hero image preloaded and responsive
- No layout shift from images: fixed aspect ratios required
- Avoid infinite DOM animation timers where CSS can handle the effect
