# 10 — Release Blockers

Do not release when any item remains:

- Legacy `ARTVERSE` text exists
- Production build fails
- Missing export/import or unresolved TypeScript error
- Price, stock or payment trusted from client
- Checkout can submit twice
- Payment result relies only on redirect query
- No loading/error/empty state on critical route
- Mobile overflow at 320px
- Keyboard cannot complete checkout
- Focus is hidden or trapped incorrectly
- Reduced motion is incomplete
- Fake scarcity or client-only countdown
- Missing seller verification or COA result text
- Admin mutation without audit trail
- Secrets or card data exposed to browser storage
- Performance budgets materially exceeded without approved exception
