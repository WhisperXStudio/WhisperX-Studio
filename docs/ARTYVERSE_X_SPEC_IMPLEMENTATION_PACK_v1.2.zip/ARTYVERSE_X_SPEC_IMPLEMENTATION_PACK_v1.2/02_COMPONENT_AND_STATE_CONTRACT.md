# 02 — Component and State Contract

## Core brand components

### OrbitPortal
Purpose: onboarding, contextual help, status feedback.
States: `idle`, `guide`, `thinking`, `alert`, `success`, `offline`.
Rules: never blocks CTA; decorative loops pause offscreen; static fallback required.

### ProductCapsule
Anatomy: media, edition badge, title, seller, price, stock, save, primary action.
States: `default`, `hover`, `focus`, `saved`, `low-stock`, `sold-out`, `loading`.
Mobile: 1-column or 2-up compact; no hover-only information.

### DropReactor
Anatomy: title, countdown, stock, rules, queue/CTA, trust copy.
States: `upcoming`, `live`, `queue`, `reserved`, `sold-out`, `ended`, `error`.
Timer must come from server time and must not move the CTA.

### MagneticCTA
Variants: `primary`, `secondary`, `ghost`, `danger`.
States: `default`, `hover`, `pressed`, `focus`, `disabled`, `loading`, `success`.
Reduced motion: remove attraction/parallax; retain color and outline feedback.

### COALock
States: `checking`, `verified`, `invalid`, `revoked`, `offline`.
Always show textual result and serial metadata.

## Commerce components

- SmartHeader
- SearchCommand
- FilterDock
- PriceBlock
- QuantityControl
- SellerTrustCard
- ShippingTimeline
- CheckoutStepper
- ReturnStatus
- ToastStack
- EmptyState
- ErrorBoundarySurface
- BottomOrbNav

## Dashboard components

- RoleShell
- MetricCard
- SignalList
- DataTable / MobileCardList
- ChartPanel
- BulkActionBar
- ModerationPanel
- AuditTimeline
- PermissionGate

## State naming contract

Use the same state names in Figma variants, TypeScript unions and tests.

```ts
type AsyncState = 'idle' | 'loading' | 'success' | 'empty' | 'error' | 'offline';
type StockState = 'available' | 'low-stock' | 'reserved' | 'sold-out';
type PaymentState = 'draft' | 'processing' | 'pending' | 'paid' | 'failed' | 'refunded';
type OrderState = 'created' | 'confirmed' | 'packing' | 'shipped' | 'delivered' | 'return-requested' | 'returned' | 'cancelled';
```

## Component rules

- Typed public props; no `any`
- Semantic element by default
- Visible focus style
- Minimum touch target 44×44px
- Loading state must preserve layout
- Destructive actions require confirmation
- Business state must be separate from animation state
